/**
 * The app's ONLY Cloud Function. Everything else (matchmaking, signaling)
 * runs client-side against Firestore directly — see the README for why.
 *
 * This one exists because "how many times has this user been reported"
 * has to be counted somewhere the client can't lie to. The Admin SDK
 * here bypasses firestore.rules entirely, which is exactly the point.
 *
 * Deploy with:
 *   cd functions && npm install
 *   firebase deploy --only functions
 * Requires the Blaze (pay-as-you-go) plan — Cloud Functions aren't
 * available on Spark. At the traffic this app sees pre-scale, invocation
 * costs round to zero (see the cost breakdown discussed earlier).
 */

const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');

initializeApp();
const db = getFirestore();

const AUTO_SUSPEND_THRESHOLD = 3;

exports.onReportCreated = onDocumentCreated('reports/{reportId}', async (event) => {
  const report = event.data.data();
  const reportedUid = report.reportedUid;
  if (!reportedUid) return;

  const reportsSnap = await db
    .collection('reports')
    .where('reportedUid', '==', reportedUid)
    .get();

  if (reportsSnap.size >= AUTO_SUSPEND_THRESHOLD) {
    await db.collection('suspensions').doc(reportedUid).set({
      suspendedAt: FieldValue.serverTimestamp(),
      reportCount: reportsSnap.size,
    });
  }
});
