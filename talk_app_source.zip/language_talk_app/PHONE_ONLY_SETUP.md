# Building and testing this from a phone only

You genuinely can do this whole loop from a phone browser. The trick is:
do a ~15 minute one-time setup in a free cloud dev environment (which you
control through your phone's browser, not a local install), commit the
result, and every build after that happens automatically on GitHub's
servers — you never touch a terminal again unless you want to.

## Part A — one-time setup (~15 min, needs a GitHub account)

1. **Create a new empty repo** at github.com (works fine in mobile Chrome/Safari) — e.g. `talk-app`.

2. **Open a Codespace on it**: on the repo page → green "Code" button →
   "Codespaces" tab → "Create codespace on main". This opens a full
   VS Code environment in your browser, running on a cloud machine.

3. **Upload this project into it**: in the Codespace's file explorer
   (left sidebar), right-click → "Upload..." → pick `talk_app_source.zip`
   (the file from earlier in this chat — download it to your phone first
   if you haven't). Then in the terminal at the bottom:
   ```
   unzip talk_app_source.zip
   mv language_talk_app/* language_talk_app/.[!.]* . 2>/dev/null
   rmdir language_talk_app
   ```

4. **Generate the native Android/iOS scaffolding** (this is the part
   that genuinely needs a real toolchain — Codespaces has Flutter
   pre-installable):
   ```
   flutter --version
   ```
   If that fails, run: `git clone https://github.com/flutter/flutter.git -b stable --depth 1 && export PATH="$PATH:$PWD/flutter/bin" && flutter precache`
   Then:
   ```
   flutter create --org com.yourcompany --project-name talk_app .
   ```
   This fills in the missing `android/` and `ios/` folders without
   touching your existing `lib/` or `pubspec.yaml`.

5. **Merge the Android permissions**: open
   `android/app/src/main/AndroidManifest.xml` in the Codespace editor.
   Copy the `<uses-permission...>` lines from
   `android_manifest_snippet.xml` in just below the opening `<manifest ...>`
   tag, and copy the `<meta-data android:name="com.google.android.gms.ads...">`
   block in just before the manifest's closing `</application>` tag.

6. **Connect Firebase**:
   ```
   dart pub global activate flutterfire_cli
   firebase login --no-localhost
   ```
   (`--no-localhost` prints a URL — open it, log in, it gives you a code
   to paste back into the terminal. Works fine from a phone.)
   ```
   flutterfire configure
   ```
   This overwrites `lib/firebase_options.dart` with your real project.

7. **Commit and push everything**:
   ```
   git add -A
   git commit -m "native scaffolding + firebase config"
   git push
   ```

That last push triggers `.github/workflows/build_apk.yml` automatically.

## Part B — every build after this (no terminal needed)

1. Make any small edit (e.g. swap in real AdMob IDs) using **github.dev**:
   go to your repo, press the `.` key (or change `github.com` to
   `github.dev` in the URL) — this opens a full lightweight code editor
   in the browser, phone-friendly. Edit, commit, done.
2. Go to the **Actions** tab on the repo → watch the build run (~3-5 min).
3. Open the finished run → scroll to **Artifacts** → download
   `talk-app-debug-apk` (downloads as a `.zip` containing the `.apk`).
4. On your phone: extract the zip (any file manager or a "zip extractor"
   app), tap the `.apk`, allow "install from unknown sources" if asked,
   install.

## Part C — the two-device problem

Matching pairs two different anonymous users, so testing the actual call
needs a second phone somewhere. Ranked by how well it actually works:

1. **Borrow any second Android phone** (friend's, old spare) — install
   the same APK, real conditions, real audio. This is the only option
   that fully tests it.
2. **A second Android user profile on your own phone** (Settings →
   System → Multiple users → Add user) — install the app under both
   profiles. Good for confirming matchmaking pairs correctly and
   Firestore docs look right (watch the Firebase console in your
   browser while switching profiles), but Android only runs one profile
   on-screen at a time, so you can't verify live two-way audio this way.
3. **A cloud device farm** (BrowserStack App Live, Firebase Test Lab —
   both have free tiers, both usable from a phone browser) — install
   the APK on a real remote phone alongside your physical one. Confirms
   UI/matching behavior; mic/audio simulation on these services is
   often limited, so don't rely on it for verifying call quality.

## Part D — what you can fully verify with just your one phone
- Onboarding (gender/age, only-shows-once behavior)
- Home screen, dictionary lookups, settings
- Ads loading (Google's test creative should appear)
- Backend correctness — open the Firebase console in your phone browser
  and watch `matchQueue`/`calls`/`reports` documents appear live as you
  use the app solo (you'll sit in the queue since there's no partner,
  but you'll see your own queue doc get created correctly)
