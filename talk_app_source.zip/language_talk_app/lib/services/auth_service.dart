import 'package:firebase_auth/firebase_auth.dart';

/// "No login" from the user's point of view — there's genuinely no email,
/// password, or sign-in screen anywhere in this app. Under the hood we
/// still sign in anonymously so Firestore's security rules have a stable
/// `request.auth.uid` to check ownership against (who's allowed to delete
/// a queue entry, who wrote a report, etc). This happens once, silently,
/// on first launch, and persists across app restarts automatically.
class AuthService {
  AuthService._();
  static final AuthService instance = AuthService._();

  Future<String> ensureSignedIn() async {
    final auth = FirebaseAuth.instance;
    if (auth.currentUser != null) return auth.currentUser!.uid;
    final cred = await auth.signInAnonymously();
    return cred.user!.uid;
  }

  String? get uid => FirebaseAuth.instance.currentUser?.uid;
}
