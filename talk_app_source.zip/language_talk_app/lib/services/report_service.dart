import 'package:cloud_firestore/cloud_firestore.dart';
import 'local_storage_service.dart';

enum ReportReason { harassment, sexualContent, hateSpeech, spam, minorSafety, other }

/// Random-voice-chat-with-strangers apps live or die on this file.
/// It's also a practical requirement, not just a nice-to-have: Play Store's
/// User Generated Content policy and AdMob's policies for chat-matching
/// apps both expect in-app block/report before they'll keep serving ads
/// to an app like this.
///
/// Note what this class deliberately does NOT do: write to `suspensions`
/// directly. A client that can decide "I'm suspended? No I'm not" is not
/// a safety feature. Counting reports and flipping that flag happens
/// server-side in a Cloud Function (see functions/index.js) using the
/// Admin SDK, which the security rules can't be bypassed by definition.
class ReportService {
  ReportService({FirebaseFirestore? firestore, LocalStorageService? storage})
      : _db = firestore ?? FirebaseFirestore.instance,
        _storage = storage ?? LocalStorageService();

  final FirebaseFirestore _db;
  final LocalStorageService _storage;

  Future<void> blockUser(String myUid, String otherUid) async {
    await _storage.addBlockedId(otherUid);
    await _db.collection('blocks').add({
      'blockedBy': myUid,
      'blockedUid': otherUid,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> reportUser({
    required String reporterUid,
    required String reportedUid,
    required String callId,
    required ReportReason reason,
  }) async {
    // Always block alongside report — the person reporting shouldn't
    // have to take two separate actions to stop seeing that user.
    await blockUser(reporterUid, reportedUid);

    await _db.collection('reports').add({
      'reporterUid': reporterUid,
      'reportedUid': reportedUid,
      'callId': callId,
      'reason': reason.name,
      'createdAt': FieldValue.serverTimestamp(),
    });
    // Auto-suspend threshold is evaluated server-side by a Cloud Function
    // watching this collection — see functions/index.js.
  }

  Future<bool> isSuspended(String uid) async {
    final doc = await _db.collection('suspensions').doc(uid).get();
    return doc.exists;
  }

  Future<List<String>> blockedIds() => _storage.getBlockedIds();
}
