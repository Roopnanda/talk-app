import 'dart:io';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:facebook_audience_network/facebook_audience_network.dart';

/// Wraps both ad networks behind one API so screens never touch the SDKs
/// directly. AdMob is the primary demand source; Meta is wired in as a
/// second network you call directly when AdMob has no fill (a simple
/// "waterfall of two" — swap for AdMob's built-in mediation later if you
/// want automatic bidding between more networks).
///
/// ⚠️ Replace every ad unit ID below with your own from the AdMob and
/// Meta Audience Network dashboards before release. The ones here are
/// Google's public TEST ids — they're safe to leave in during development
/// but will not earn anything and must not ship to production.
class AdsService {
  AdsService._();
  static final AdsService instance = AdsService._();

  InterstitialAd? _interstitial;
  RewardedAd? _rewarded;
  bool _metaReady = false;

  // --- Test IDs (Google's official test units) ---------------------------
  static String get _bannerUnitId => Platform.isAndroid
      ? 'ca-app-pub-3940256099942544/6300978111'
      : 'ca-app-pub-3940256099942544/2934735716';

  static String get _interstitialUnitId => Platform.isAndroid
      ? 'ca-app-pub-3940256099942544/1033173712'
      : 'ca-app-pub-3940256099942544/4411468910';

  static String get _rewardedUnitId => Platform.isAndroid
      ? 'ca-app-pub-3940256099942544/5224354917'
      : 'ca-app-pub-3940256099942544/1712485313';

  static const String _metaInterstitialPlacementId = 'YOUR_META_INTERSTITIAL_PLACEMENT_ID';
  static const String _metaBannerPlacementId = 'YOUR_META_BANNER_PLACEMENT_ID';

  Future<void> init() async {
    await MobileAds.instance.initialize();
    try {
      await FacebookAudienceNetwork.init(
        testingId: null, // set your device hash here while testing
      );
      _metaReady = true;
    } catch (_) {
      // Meta SDK not configured yet — app still runs fine on AdMob alone.
      _metaReady = false;
    }
    _loadInterstitial();
    _loadRewarded();
  }

  bool get metaReady => _metaReady;

  // --- Banner (AdMob primary; drop-in Meta banner widget documented below)
  BannerAd createBannerAd({required void Function(Ad) onLoaded}) {
    final banner = BannerAd(
      adUnitId: _bannerUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(onAdLoaded: onLoaded),
    );
    banner.load();
    return banner;
  }

  // --- Interstitial: shown between calls (natural break, not mid-call) ---
  void _loadInterstitial() {
    InterstitialAd.load(
      adUnitId: _interstitialUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) => _interstitial = ad,
        onAdFailedToLoad: (_) => _interstitial = null,
      ),
    );
  }

  /// Call after a call ends / before returning to the queue.
  /// Falls back to Meta's interstitial if AdMob has no fill.
  Future<void> showInterstitialBetweenCalls() async {
    if (_interstitial != null) {
      _interstitial!.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (ad) {
          ad.dispose();
          _loadInterstitial();
        },
      );
      await _interstitial!.show();
      _interstitial = null;
      return;
    }
    if (_metaReady) {
      FacebookInterstitialAd.loadInterstitialAd(
        placementId: _metaInterstitialPlacementId,
        listener: (result, value) {
          if (result == InterstitialAdResult.LOADED) {
            FacebookInterstitialAd.showInterstitialAd();
          }
        },
      );
    }
  }

  // --- Rewarded: optional "skip the wait" or "reveal translation" perk ---
  void _loadRewarded() {
    RewardedAd.load(
      adUnitId: _rewardedUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) => _rewarded = ad,
        onAdFailedToLoad: (_) => _rewarded = null,
      ),
    );
  }

  Future<void> showRewarded({required void Function() onEarned}) async {
    if (_rewarded == null) return;
    await _rewarded!.show(
      onUserEarnedReward: (ad, reward) => onEarned(),
    );
    _rewarded!.dispose();
    _rewarded = null;
    _loadRewarded();
  }
}
