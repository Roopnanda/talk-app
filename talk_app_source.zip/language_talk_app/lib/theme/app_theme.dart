import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Design language: "Frosted Dusk"
/// A deep indigo-to-violet night sky with a single glowing aqua accent
/// that stands in for the human voice — everything else stays quiet
/// so that accent (and the voice orb built from it) reads as the signature.
class AppColors {
  AppColors._();

  static const Color bgTop = Color(0xFF0A0E27); // near-midnight indigo
  static const Color bgBottom = Color(0xFF231651); // deep violet
  static const Color accent = Color(0xFF4EF0D6); // signature aqua — "voice"
  static const Color accentSoft = Color(0xFF7C8CFF); // secondary glow, blues
  static const Color warn = Color(0xFFFF6B81); // report/hangup only
  static const Color glassFill = Color(0x14FFFFFF); // 8% white
  static const Color glassBorder = Color(0x33FFFFFF); // 20% white
  static const Color textPrimary = Color(0xFFF3F5FF);
  static const Color textMuted = Color(0xFFA6ADD1);
}

class AppGradients {
  AppGradients._();

  static const LinearGradient sky = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [AppColors.bgTop, AppColors.bgBottom],
  );

  static const LinearGradient accentGlow = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [AppColors.accent, AppColors.accentSoft],
  );
}

class AppTextTheme {
  AppTextTheme._();

  // Display face: Space Grotesk — geometric with slightly quirky terminals,
  // reads as confident/modern without being another rounded-sans default.
  // Body face: Manrope — clean, humanist, highly legible at small sizes.
  static TextTheme get textTheme => TextTheme(
        displayLarge: GoogleFonts.spaceGrotesk(
          fontSize: 34,
          fontWeight: FontWeight.w700,
          color: AppColors.textPrimary,
          letterSpacing: -0.5,
        ),
        headlineMedium: GoogleFonts.spaceGrotesk(
          fontSize: 24,
          fontWeight: FontWeight.w600,
          color: AppColors.textPrimary,
          letterSpacing: -0.2,
        ),
        titleMedium: GoogleFonts.spaceGrotesk(
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: AppColors.textPrimary,
        ),
        bodyLarge: GoogleFonts.manrope(
          fontSize: 16,
          fontWeight: FontWeight.w500,
          color: AppColors.textPrimary,
        ),
        bodyMedium: GoogleFonts.manrope(
          fontSize: 14,
          fontWeight: FontWeight.w500,
          color: AppColors.textMuted,
        ),
        labelLarge: GoogleFonts.manrope(
          fontSize: 15,
          fontWeight: FontWeight.w700,
          color: AppColors.bgTop,
        ),
      );
}

ThemeData buildAppTheme() {
  return ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: AppColors.bgTop,
    fontFamily: GoogleFonts.manrope().fontFamily,
    textTheme: AppTextTheme.textTheme,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.accent,
      secondary: AppColors.accentSoft,
      error: AppColors.warn,
      surface: AppColors.bgTop,
    ),
    useMaterial3: true,
  );
}
