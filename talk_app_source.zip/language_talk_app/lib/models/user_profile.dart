enum Gender { male, female, other }

extension GenderLabel on Gender {
  String get label => switch (this) {
        Gender.male => 'Male',
        Gender.female => 'Female',
        Gender.other => 'Other',
      };

  String get storageValue => name; // 'male' | 'female' | 'other'

  static Gender fromStorage(String value) => Gender.values.firstWhere(
        (g) => g.storageValue == value,
        orElse: () => Gender.other,
      );
}

class UserProfile {
  const UserProfile({
    required this.uid,
    required this.gender,
    required this.isAdult,
  });

  final String uid;
  final Gender gender;
  final bool isAdult;
}
