import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// The app's signature element: a breathing, ringed orb that stands in for
/// a voice. Idle = slow single pulse. Listening/talking = faster, and an
/// extra ring reacts to [audioLevel] (0.0–1.0) if you wire it to the mic.
class VoiceOrb extends StatefulWidget {
  const VoiceOrb({
    super.key,
    this.size = 180,
    this.active = false,
    this.audioLevel = 0.0,
  });

  final double size;
  final bool active;
  final double audioLevel;

  @override
  State<VoiceOrb> createState() => _VoiceOrbState();
}

class _VoiceOrbState extends State<VoiceOrb> with TickerProviderStateMixin {
  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 3),
  )..repeat(reverse: true);

  @override
  void didUpdateWidget(covariant VoiceOrb oldWidget) {
    super.didUpdateWidget(oldWidget);
    _pulse.duration =
        widget.active ? const Duration(milliseconds: 1100) : const Duration(seconds: 3);
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _pulse,
      builder: (context, _) {
        final t = _pulse.value; // 0..1..0
        final ringScale = 1.0 + t * 0.35 + widget.audioLevel * 0.25;
        return SizedBox(
          width: widget.size * 1.8,
          height: widget.size * 1.8,
          child: Center(
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Outer breathing ring
                Opacity(
                  opacity: (1 - t) * 0.5,
                  child: Container(
                    width: widget.size * ringScale,
                    height: widget.size * ringScale,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.accent, width: 1.5),
                    ),
                  ),
                ),
                // Core orb
                Container(
                  width: widget.size,
                  height: widget.size,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: AppGradients.accentGlow,
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.accent.withOpacity(0.45),
                        blurRadius: 40 + widget.audioLevel * 30,
                        spreadRadius: 4 + widget.audioLevel * 10,
                      ),
                    ],
                  ),
                  child: Icon(
                    widget.active ? Icons.graphic_eq_rounded : Icons.mic_none_rounded,
                    color: AppColors.bgTop,
                    size: widget.size * 0.34,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
