import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// The frosted-glass surface used everywhere: cards, buttons, sheets.
/// BackdropFilter blurs whatever gradient/orb glow sits behind it, so the
/// translucency actually shows movement instead of looking like a flat
/// semi-transparent PNG.
class GlassContainer extends StatelessWidget {
  const GlassContainer({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.margin,
    this.borderRadius = 28,
    this.blur = 18,
    this.fillOpacity,
    this.borderColor,
  });

  final Widget child;
  final EdgeInsets padding;
  final EdgeInsets? margin;
  final double borderRadius;
  final double blur;
  final double? fillOpacity;
  final Color? borderColor;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin ?? EdgeInsets.zero,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              color: fillOpacity != null
                  ? Colors.white.withOpacity(fillOpacity!)
                  : AppColors.glassFill,
              borderRadius: BorderRadius.circular(borderRadius),
              border: Border.all(
                color: borderColor ?? AppColors.glassBorder,
                width: 1,
              ),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}
