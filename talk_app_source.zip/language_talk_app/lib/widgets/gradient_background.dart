import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Full-screen backdrop: deep sky gradient + two slow-drifting colour
/// blobs. This is what the glass cards actually blur against — without
/// something moving behind it, "translucent" just looks grey.
class GradientBackground extends StatefulWidget {
  const GradientBackground({super.key, required this.child});

  final Widget child;

  @override
  State<GradientBackground> createState() => _GradientBackgroundState();
}

class _GradientBackgroundState extends State<GradientBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 18),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(decoration: const BoxDecoration(gradient: AppGradients.sky)),
        AnimatedBuilder(
          animation: _controller,
          builder: (context, _) {
            final t = _controller.value * 2 * math.pi;
            return Stack(
              children: [
                _blob(
                  color: AppColors.accent,
                  size: 260,
                  dx: 0.72 + 0.06 * math.sin(t),
                  dy: 0.14 + 0.04 * math.cos(t),
                  opacity: 0.22,
                ),
                _blob(
                  color: AppColors.accentSoft,
                  size: 320,
                  dx: 0.15 + 0.05 * math.cos(t),
                  dy: 0.68 + 0.05 * math.sin(t),
                  opacity: 0.18,
                ),
              ],
            );
          },
        ),
        widget.child,
      ],
    );
  }

  Widget _blob({
    required Color color,
    required double size,
    required double dx,
    required double dy,
    required double opacity,
  }) {
    return Align(
      alignment: Alignment(dx * 2 - 1, dy * 2 - 1),
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color.withOpacity(opacity),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(opacity * 0.8),
              blurRadius: 120,
              spreadRadius: 40,
            ),
          ],
        ),
      ),
    );
  }
}
