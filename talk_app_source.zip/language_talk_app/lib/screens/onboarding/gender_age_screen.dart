import 'package:flutter/material.dart';
import '../../models/user_profile.dart';
import '../../services/local_storage_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/glass_container.dart';
import '../../widgets/gradient_background.dart';
import '../../widgets/primary_button.dart';
import '../home/home_screen.dart';

/// The ONLY screen a new user ever has to get through. One tap for gender,
/// one tap to confirm age, done — this never shows again after
/// LocalStorageService.saveOnboarding() runs, per SplashGate's check.
///
/// The age toggle is the one addition beyond what was asked for: Play
/// Store's policy for apps that match strangers for real-time chat, and
/// AdMob's ad-serving policy for the same category, both expect some
/// age signal before matching is enabled. It's a single extra tap on the
/// same screen, not a separate flow.
class GenderAgeScreen extends StatefulWidget {
  const GenderAgeScreen({super.key});

  @override
  State<GenderAgeScreen> createState() => _GenderAgeScreenState();
}

class _GenderAgeScreenState extends State<GenderAgeScreen> {
  Gender? _selected;
  bool _confirmedAdult = false;
  final _storage = LocalStorageService();

  bool get _canContinue => _selected != null && _confirmedAdult;

  Future<void> _continue() async {
    await _storage.saveOnboarding(gender: _selected!, isAdult: _confirmedAdult);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientBackground(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Welcome', style: Theme.of(context).textTheme.displayLarge),
                const SizedBox(height: 8),
                Text(
                  "Quick setup — you won't see this again.",
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 40),
                Text('I am...', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 14),
                Row(
                  children: Gender.values
                      .map((g) => Expanded(child: _GenderCard(
                            gender: g,
                            selected: _selected == g,
                            onTap: () => setState(() => _selected = g),
                          )))
                      .toList()
                      .expand((w) => [w, const SizedBox(width: 12)])
                      .toList()
                    ..removeLast(),
                ),
                const SizedBox(height: 28),
                GlassContainer(
                  borderRadius: 20,
                  child: Row(
                    children: [
                      Checkbox(
                        value: _confirmedAdult,
                        activeColor: AppColors.accent,
                        checkColor: AppColors.bgTop,
                        side: const BorderSide(color: AppColors.glassBorder),
                        onChanged: (v) => setState(() => _confirmedAdult = v ?? false),
                      ),
                      Expanded(
                        child: Text(
                          "I confirm I'm 18 years or older",
                          style: Theme.of(context).textTheme.bodyLarge,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 28),
                Center(
                  child: PrimaryButton(
                    label: 'Continue',
                    onPressed: _canContinue ? _continue : null,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _GenderCard extends StatelessWidget {
  const _GenderCard({required this.gender, required this.selected, required this.onTap});

  final Gender gender;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: GlassContainer(
        borderRadius: 20,
        padding: const EdgeInsets.symmetric(vertical: 18),
        borderColor: selected ? AppColors.accent : AppColors.glassBorder,
        fillOpacity: selected ? 0.16 : 0.08,
        child: Column(
          children: [
            Icon(
              switch (gender) {
                Gender.male => Icons.male_rounded,
                Gender.female => Icons.female_rounded,
                Gender.other => Icons.diversity_1_rounded,
              },
              color: selected ? AppColors.accent : AppColors.textMuted,
              size: 26,
            ),
            const SizedBox(height: 8),
            Text(
              gender.label,
              style: TextStyle(
                color: selected ? AppColors.textPrimary : AppColors.textMuted,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
