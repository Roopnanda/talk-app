import 'package:flutter/material.dart';
import '../../services/local_storage_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/gradient_background.dart';
import '../../widgets/voice_orb.dart';
import '../home/home_screen.dart';
import '../onboarding/gender_age_screen.dart';

/// First widget shown on every launch. Checks local storage once and
/// routes accordingly — this single check is the entire mechanism behind
/// "ask once, then straight to home forever after."
class SplashGate extends StatefulWidget {
  const SplashGate({super.key});

  @override
  State<SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<SplashGate> {
  @override
  void initState() {
    super.initState();
    _route();
  }

  Future<void> _route() async {
    final onboarded = await LocalStorageService().hasOnboarded();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => onboarded ? const HomeScreen() : const GenderAgeScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GradientBackground(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const VoiceOrb(size: 90),
              const SizedBox(height: 20),
              Text('Talk', style: Theme.of(context).textTheme.headlineMedium),
            ],
          ),
        ),
      ),
    );
  }
}
